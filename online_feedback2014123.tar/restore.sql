create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.questions DROP CONSTRAINT questions_creator_id_fkey;
ALTER TABLE ONLY public.questions DROP CONSTRAINT questions_c_id_fkey;
ALTER TABLE ONLY public.employee_answers DROP CONSTRAINT employee_answers_qid_fkey;
ALTER TABLE ONLY public.employee_answers DROP CONSTRAINT employee_answers_creator_id_fkey;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_creator_id_fkey;
ALTER TABLE ONLY public.user_account DROP CONSTRAINT user_account_pkey;
ALTER TABLE ONLY public.user_account DROP CONSTRAINT user_account_email_key;
ALTER TABLE ONLY public.sys_user_action_logs DROP CONSTRAINT sys_user_action_logs_pkey;
ALTER TABLE ONLY public.questions DROP CONSTRAINT questions_pkey;
ALTER TABLE ONLY public.employee_logs DROP CONSTRAINT employee_logs_pkey;
ALTER TABLE ONLY public.employee_answers DROP CONSTRAINT employee_answers_pkey;
ALTER TABLE ONLY public.email_recipient DROP CONSTRAINT email_recipients_pkey;
ALTER TABLE ONLY public.email_recipient DROP CONSTRAINT email_recipients_decription_key;
ALTER TABLE ONLY public.concessionaire DROP CONSTRAINT concessionaire_pkey;
ALTER TABLE ONLY public.concessionaire DROP CONSTRAINT concessionaire_description_key;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_pkey;
DROP TABLE public.user_account;
DROP TABLE public.sys_user_action_logs;
DROP TABLE public.questions;
DROP TABLE public.employee_logs;
DROP TABLE public.employee_answers;
DROP TABLE public.email_recipient;
DROP TABLE public.concessionaire;
DROP TABLE public.category;
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: 
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: category; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE category (
    id integer NOT NULL,
    creator_id integer,
    created timestamp without time zone NOT NULL,
    category_name character varying(150) NOT NULL,
    idconcessionaire integer
);


ALTER TABLE public.category OWNER TO webuser;

--
-- Name: concessionaire; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE concessionaire (
    idconcessionaire serial NOT NULL,
    creator_id integer,
    created_at timestamp(0) without time zone DEFAULT now(),
    description character varying(200)
);


ALTER TABLE public.concessionaire OWNER TO webuser;

--
-- Name: concessionaire_idconcessionaire_seq; Type: SEQUENCE SET; Schema: public; Owner: webuser
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('concessionaire', 'idconcessionaire'), 73, true);


--
-- Name: email_recipient; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE email_recipient (
    id serial NOT NULL,
    email character varying(80),
    active boolean DEFAULT false,
    created_at timestamp(0) without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_recipient OWNER TO webuser;

--
-- Name: email_recipient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webuser
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('email_recipient', 'id'), 38, true);


--
-- Name: employee_answers; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE employee_answers (
    id integer NOT NULL,
    q_id integer,
    creator_id integer,
    actionstamp timestamp without time zone NOT NULL,
    username character varying(150) NOT NULL,
    value character varying(150) NOT NULL
);


ALTER TABLE public.employee_answers OWNER TO webuser;

--
-- Name: employee_logs; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE employee_logs (
    id integer NOT NULL,
    username character varying(150) NOT NULL,
    actionstamp timestamp without time zone NOT NULL
);


ALTER TABLE public.employee_logs OWNER TO webuser;

--
-- Name: questions; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE questions (
    id integer NOT NULL,
    c_id integer,
    creator_id integer,
    created timestamp without time zone NOT NULL,
    description character varying(150) NOT NULL,
    "type" character varying(150) NOT NULL
);


ALTER TABLE public.questions OWNER TO webuser;

--
-- Name: sys_user_action_logs; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE sys_user_action_logs (
    idsys_user_action_logs serial NOT NULL,
    module character varying(80),
    affected_id integer DEFAULT (-1),
    affected_data text NOT NULL,
    username character varying(255),
    actionstamp timestamp(0) without time zone DEFAULT now(),
    method character varying(100)
);


ALTER TABLE public.sys_user_action_logs OWNER TO webuser;

--
-- Name: sys_user_action_logs_idsys_user_action_logs_seq; Type: SEQUENCE SET; Schema: public; Owner: webuser
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sys_user_action_logs', 'idsys_user_action_logs'), 139, true);


--
-- Name: user_account; Type: TABLE; Schema: public; Owner: webuser; Tablespace: 
--

CREATE TABLE user_account (
    id integer NOT NULL,
    username character varying(150) NOT NULL,
    user_role character varying(50) NOT NULL,
    active boolean NOT NULL,
    email character varying(80),
    "password" character varying(65)
);


ALTER TABLE public.user_account OWNER TO webuser;

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY category (id, creator_id, created, category_name, idconcessionaire) FROM stdin;
\.
copy category (id, creator_id, created, category_name, idconcessionaire)  from '$$PATH$$/1571.dat' ;
--
-- Data for Name: concessionaire; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY concessionaire (idconcessionaire, creator_id, created_at, description) FROM stdin;
\.
copy concessionaire (idconcessionaire, creator_id, created_at, description)  from '$$PATH$$/1575.dat' ;
--
-- Data for Name: email_recipient; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY email_recipient (id, email, active, created_at) FROM stdin;
\.
copy email_recipient (id, email, active, created_at)  from '$$PATH$$/1576.dat' ;
--
-- Data for Name: employee_answers; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY employee_answers (id, q_id, creator_id, actionstamp, username, value) FROM stdin;
\.
copy employee_answers (id, q_id, creator_id, actionstamp, username, value)  from '$$PATH$$/1573.dat' ;
--
-- Data for Name: employee_logs; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY employee_logs (id, username, actionstamp) FROM stdin;
\.
copy employee_logs (id, username, actionstamp)  from '$$PATH$$/1574.dat' ;
--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY questions (id, c_id, creator_id, created, description, "type") FROM stdin;
\.
copy questions (id, c_id, creator_id, created, description, "type")  from '$$PATH$$/1572.dat' ;
--
-- Data for Name: sys_user_action_logs; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY sys_user_action_logs (idsys_user_action_logs, module, affected_id, affected_data, username, actionstamp, method) FROM stdin;
\.
copy sys_user_action_logs (idsys_user_action_logs, module, affected_id, affected_data, username, actionstamp, method)  from '$$PATH$$/1577.dat' ;
--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: webuser
--

COPY user_account (id, username, user_role, active, email, "password") FROM stdin;
\.
copy user_account (id, username, user_role, active, email, "password")  from '$$PATH$$/1570.dat' ;
--
-- Name: category_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: concessionaire_description_key; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY concessionaire
    ADD CONSTRAINT concessionaire_description_key UNIQUE (description);


--
-- Name: concessionaire_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY concessionaire
    ADD CONSTRAINT concessionaire_pkey PRIMARY KEY (idconcessionaire);


--
-- Name: email_recipients_decription_key; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY email_recipient
    ADD CONSTRAINT email_recipients_decription_key UNIQUE (email);


--
-- Name: email_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY email_recipient
    ADD CONSTRAINT email_recipients_pkey PRIMARY KEY (id);


--
-- Name: employee_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY employee_answers
    ADD CONSTRAINT employee_answers_pkey PRIMARY KEY (id);


--
-- Name: employee_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY employee_logs
    ADD CONSTRAINT employee_logs_pkey PRIMARY KEY (id);


--
-- Name: questions_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: sys_user_action_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY sys_user_action_logs
    ADD CONSTRAINT sys_user_action_logs_pkey PRIMARY KEY (idsys_user_action_logs);


--
-- Name: user_account_email_key; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY user_account
    ADD CONSTRAINT user_account_email_key UNIQUE (email);


--
-- Name: user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: webuser; Tablespace: 
--

ALTER TABLE ONLY user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: category_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: webuser
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES user_account(id);


--
-- Name: employee_answers_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: webuser
--

ALTER TABLE ONLY employee_answers
    ADD CONSTRAINT employee_answers_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES user_account(id);


--
-- Name: employee_answers_qid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: webuser
--

ALTER TABLE ONLY employee_answers
    ADD CONSTRAINT employee_answers_qid_fkey FOREIGN KEY (q_id) REFERENCES questions(id) ON DELETE CASCADE;


--
-- Name: questions_c_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: webuser
--

ALTER TABLE ONLY questions
    ADD CONSTRAINT questions_c_id_fkey FOREIGN KEY (c_id) REFERENCES category(id);


--
-- Name: questions_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: webuser
--

ALTER TABLE ONLY questions
    ADD CONSTRAINT questions_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES user_account(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

